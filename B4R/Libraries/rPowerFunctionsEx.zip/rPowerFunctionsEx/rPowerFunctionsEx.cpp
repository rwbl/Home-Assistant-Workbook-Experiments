#include "B4RDefines.h"

namespace B4R {
	void B4RPowerFunctionsEx::Initialize(Byte Pin, Byte Channel) {
		pfex = new (backend) PowerFunctionsEx(Pin, Channel);
	}

	void B4RPowerFunctionsEx::singlePWM(UInt output, UInt pwm) {
		pfex->single_pwm(output, pwm);		
	}

	void B4RPowerFunctionsEx::singleIncrement(UInt i) {
		pfex->single_increment(i);
	}

	void B4RPowerFunctionsEx::singleDecrement(UInt d) {
		pfex->single_decrement(d);
	}

	void B4RPowerFunctionsEx::redPWM(UInt r) {
		pfex->red_pwm(r);
	}

	void B4RPowerFunctionsEx::bluePWM(UInt b) {
		pfex->blue_pwm(b);
	}

	void B4RPowerFunctionsEx::comboPWM(UInt p, UInt v) {
		pfex->combo_pwm(p, v);
	}


}
