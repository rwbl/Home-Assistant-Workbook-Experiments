# LEGO Power Functions

## Links
https://www.philohome.com/pf/LEGO_Power_Functions_RC_v120.pdf
https://circuitcellar.com/research-design-hub/projects/build-an-ir-based-lego-train-controller-part-1/
https://www.philohome.com/pf/pf.htm
https://oberguru.net/lego/power-functions.html

## Technical Details

### IR Protokoll
Details: https://oberguru.net/lego/LEGO_Power_Functions_RC_v120.pdf
LEGO: 38 KHz Frequenz.

Es gibt verschiedene Modi: Extended Mode, Combo Diret Mode, Single Output Mode und Combo PWM Mode.
Datenpaket

Jede Paket besteht aus einem Start und Stop Bit sowie aus 2 x 4 Bit = 16 Bit Daten.

Start | TECC aMMM DDDD LLLL | Stop

Paketbits
Bit 	Name 	Bemerkung
T 	Toggle 	Toggle Bit, Wechsel zwischen 0 und 1 (Toggle Bit Mask 0x8008)
E 	Escape 	0 = Modus Bit wählen den Modus, 1 = Combo PWM Mode
CC 	Channel 	0-3 Kanalwahl
a 	Address
MMM 	Mode 	000 = Extended, 001 = Combo Direct, 01x = Reserved, 1xx = Single Output
DDDD 	Data 	Daten, Modus abhängig
LLLL 	LRC 	0xf XOR Nibble1 XOR Nibble2 XOR Nibble3
Bitlängen
Codierung 	HIGH 	LOW
Null 	158 	263
Eins 	158 	553
Start 	158 	1026
Stop 	158 	1026

Angaben der Längen in Mikrosekunden.

Siehe auch die Erläuterung zu LIRC.
LEGO 8879 Power Functions IR Fernsteuerung - Eisenbahn

Die beiden roten Bremsbutton verwenden den Single Output Mode - Modus 0. Beide zusammen den Combo Direct Mode.
Die Drehregler erhöhen bzw. erniedrigen je nach gewählter Richtung die PWM Frequenz. Die Regler verwenden auch den Single Output Mode - jedoch den Modus 1.

    LIRC Konfiguration für Zugsteuerung
    Fernbedienung aufgeschraubt

Links

    Messungen des IR Protokoll
    IR Receiver im Detail
    Steuerung von LEGO mit Pi und Python
    LED Lichter im Detail
    Technische Details zu Power Functions
    Arduino und Power Functions
    http://ofalcao.pt/blog/2014/infrared-remote-control
    http://www.mikrocontroller.net/articles/IRMP#LEGO


## Remote Control IR Transmitter Signal
Arduino Sketch
```
#include <IRremote.hpp>

#define IR_RECEIVE_PIN 2  // Signal pin connected to D2

void setup() {
  Serial.begin(115200);
  IrReceiver.begin(IR_RECEIVE_PIN, ENABLE_LED_FEEDBACK);
}

void loop() {
  if (IrReceiver.decode()) {
      Serial.print("Received IR signal:\n");
      IrReceiver.printIRResultRawFormatted(&Serial); // Print raw data
      IrReceiver.resume();
  }
}
```

Example signal when pressing & releasing the left button on the remote.
```
Received IR signal:
rawData[36]: 
 -3276750
 + 200,- 950
 + 200,- 150 + 250,- 250 + 150,- 600 + 150,- 550
 + 150,- 150 + 250,- 550 + 200,- 150 + 200,- 300
 + 200,- 550 + 150,- 150 + 250,- 150 + 300,- 150
 + 250,- 150 + 300,- 150 + 250,- 150 + 300,- 150
 + 250
Sum: 9250
Received IR signal:
rawData[36]: 
 -214300
 + 250,- 950
 + 200,- 150 + 250,- 100 + 300,- 600 + 150,- 550
 + 150,- 150 + 250,- 550 + 200,- 150 + 250,- 100
 + 350,- 550 + 150,- 150 + 200,- 200 + 300,- 150
 + 250,- 150 + 300,- 150 + 250,- 150 + 300,- 100
 + 300
Sum: 9300
```
